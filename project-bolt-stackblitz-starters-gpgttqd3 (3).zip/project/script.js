// Game constants
const CANVAS_WIDTH = 800;
const CANVAS_HEIGHT = 600;
const GRAVITY = 0.5;
const JUMP_FORCE = -12;
const MOVE_SPEED = 5;
const PLAYER_WIDTH = 40;
const PLAYER_HEIGHT = 40;
const SCROLL_SPEED = 2;
const PLATFORM_WIDTH = 100;
const PLATFORM_HEIGHT = 20;
const GAP_MIN_WIDTH = 100;
const GAP_MAX_WIDTH = 300;
const PLATFORM_FREQUENCY = 100; // Decreased to increase platform frequency (was 300)

// Game state
let gameState = 'start';
let survivalTimer = 0;
let lastTimestamp = 0;
let scrollOffset = 0;

// Platform and gap generation
const platforms = [];
const gaps = [];
let lastPlatformX = 0;
let lastGapX = 400;

// Player state
const player = {
  x: CANVAS_WIDTH / 4,
  y: CANVAS_HEIGHT / 2,
  velocityX: 0,
  velocityY: 0,
  isGrounded: false,
  canDoubleJump: true,
  isCrouching: false,
  isSliding: false,
  health: 5,
  hunger: 8,
  lastHungerDecrease: 0,
  direction: 1,
  scale: { x: 1, y: 1 }
};

// Initialize canvas
const canvas = document.getElementById('gameCanvas');
const ctx = canvas.getContext('2d');
canvas.width = CANVAS_WIDTH;
canvas.height = CANVAS_HEIGHT;

// Input handling
const keys = {
  ArrowLeft: false,
  ArrowRight: false,
  ArrowUp: false,
  ArrowDown: false,
  Space: false,
  KeyR: false,
};

document.addEventListener('keydown', (e) => {
  if (keys.hasOwnProperty(e.code)) {
    keys[e.code] = true;
    
    if (e.code === 'Space') {
      if (gameState === 'playing') {
        gameState = 'paused';
      } else if (gameState === 'paused') {
        gameState = 'playing';
      } else if (gameState === 'gameover') {
        resetGame();
      }
    }
    
    if (e.code === 'KeyR' && gameState === 'paused') {
      resetGame();
    }
  }
});

document.addEventListener('keyup', (e) => {
  if (keys.hasOwnProperty(e.code)) {
    keys[e.code] = false;
  }
});

function generatePlatform() {
  const y = Math.random() * (CANVAS_HEIGHT - 200) + 100;
  platforms.push({
    x: lastPlatformX + Math.random() * PLATFORM_FREQUENCY + 100,
    y,
    width: PLATFORM_WIDTH,
    height: PLATFORM_HEIGHT
  });
  lastPlatformX = platforms[platforms.length - 1].x;
}

function generateGap() {
  const width = Math.random() * (GAP_MAX_WIDTH - GAP_MIN_WIDTH) + GAP_MIN_WIDTH;
  gaps.push({
    x: lastGapX + Math.random() * 500 + 300,
    width
  });
  lastGapX = gaps[gaps.length - 1].x;
}

function resetGame() {
  gameState = 'playing';
  survivalTimer = 0;
  scrollOffset = 0;
  player.x = CANVAS_WIDTH / 4;
  player.y = CANVAS_HEIGHT / 2;
  player.velocityX = 0;
  player.velocityY = 0;
  player.health = 5;
  player.hunger = 8;
  player.lastHungerDecrease = 0;
  player.isSliding = false;
  player.scale = { x: 1, y: 1 };
  platforms.length = 0;
  gaps.length = 0;
  lastPlatformX = CANVAS_WIDTH;
  lastGapX = 400;
  
  // Generate initial platforms and gaps
  for (let i = 0; i < 15; i++) { // Increased initial platforms (was 5)
    generatePlatform();
    generateGap();
  }
}

function updatePlayer(deltaTime) {
  // Handle movement
  if (keys.ArrowLeft) {
    player.velocityX = -MOVE_SPEED;
    player.direction = -1;
  } else if (keys.ArrowRight) {
    player.velocityX = MOVE_SPEED;
    player.direction = 1;
  } else {
    player.velocityX = 0;
  }
  
  // Handle jumping (new implementation)
  if (keys.ArrowUp) {
    if (player.isGrounded || player.canDoubleJump) {
      player.velocityY = JUMP_FORCE;
      
      if (!player.isGrounded) {
        player.canDoubleJump = false;
      }
    }
  }
  
  // Reset double jump when grounded
  if (player.isGrounded) {
    player.canDoubleJump = true;
  }
  
  // Handle crouching and sliding (new implementation)
  if (keys.ArrowDown) {
    player.isCrouching = true;
    if (player.velocityX !== 0 && player.isGrounded) {
      // Sliding
      player.isSliding = true;
      player.velocityX *= 1.5; // Speed boost while sliding
      player.scale.y = 0.5;
    } else {
      // Just crouching
      player.isSliding = false;
      player.scale.y = 0.5;
    }
  } else {
    player.isCrouching = false;
    player.isSliding = false;
    player.scale.y = 1;
  }
  
  // Apply gravity
  player.velocityY += GRAVITY;
  
  // Update position
  player.x += player.velocityX;
  player.y += player.velocityY;
  
  // Apply world scroll
  player.x -= SCROLL_SPEED;
  
  // Ground collision
  let onPlatform = false;
  
  // Check platform collisions
  for (const platform of platforms) {
    if (player.y + PLAYER_HEIGHT * player.scale.y >= platform.y && 
        player.y + PLAYER_HEIGHT * player.scale.y <= platform.y + platform.height &&
        player.x + PLAYER_WIDTH > platform.x && 
        player.x < platform.x + platform.width) {
      player.y = platform.y - PLAYER_HEIGHT * player.scale.y;
      player.velocityY = 0;
      player.isGrounded = true;
      onPlatform = true;
      break;
    }
  }
  
  // Check gap collisions
  for (const gap of gaps) {
    if (player.x + PLAYER_WIDTH > gap.x && 
        player.x < gap.x + gap.width && 
        player.y + PLAYER_HEIGHT * player.scale.y > CANVAS_HEIGHT - 50) {
      gameState = 'gameover';
      return;
    }
  }
  
  // Ground collision (if not on platform)
  if (!onPlatform && player.y > CANVAS_HEIGHT - PLAYER_HEIGHT * player.scale.y) {
    player.y = CANVAS_HEIGHT - PLAYER_HEIGHT * player.scale.y;
    player.velocityY = 0;
    player.isGrounded = true;
  } else if (!onPlatform) {
    player.isGrounded = false;
  }
  
  // Wall collision
  if (player.x < 0) player.x = 0;
  if (player.x > CANVAS_WIDTH - PLAYER_WIDTH) player.x = CANVAS_WIDTH - PLAYER_WIDTH;
  
  // Update hunger
  if (Date.now() - player.lastHungerDecrease >= 3000) {
    player.hunger = Math.max(0, player.hunger - 1);
    player.lastHungerDecrease = Date.now();
    
    if (player.hunger <= 2) {
      player.health = Math.max(0, player.health - 1);
    }
  }
  
  if (player.health <= 0) {
    gameState = 'gameover';
  }
}

function updateWorld() {
  scrollOffset += SCROLL_SPEED;
  
  // Update platform positions
  platforms.forEach(platform => {
    platform.x -= SCROLL_SPEED;
  });
  
  // Update gap positions
  gaps.forEach(gap => {
    gap.x -= SCROLL_SPEED;
  });
  
  // Remove off-screen platforms and generate new ones
  while (platforms.length > 0 && platforms[0].x + platforms[0].width < 0) {
    platforms.shift();
    generatePlatform();
  }
  
  // Remove off-screen gaps and generate new ones
  while (gaps.length > 0 && gaps[0].x + gaps[0].width < 0) {
    gaps.shift();
    generateGap();
  }
}

function drawPlayer() {
  ctx.fillStyle = '#000';
  const height = PLAYER_HEIGHT * player.scale.y;
  const width = player.isSliding ? PLAYER_WIDTH * 1.5 : PLAYER_WIDTH;
  
  ctx.fillRect(
    player.x, 
    player.y, 
    width,
    height
  );
}

function drawWorld() {
  // Draw ground
  ctx.fillStyle = '#87CEEB';
  ctx.fillRect(0, CANVAS_HEIGHT - 50, CANVAS_WIDTH, 50);
  
  // Draw platforms
  ctx.fillStyle = '#666';
  platforms.forEach(platform => {
    ctx.fillRect(platform.x, platform.y, platform.width, platform.height);
  });
  
  // Draw gaps
  ctx.fillStyle = '#87CEEB';
  gaps.forEach(gap => {
    ctx.fillRect(gap.x, CANVAS_HEIGHT - 50, gap.width, 50);
  });
}

function drawUI() {
  // Draw health bar
  ctx.fillStyle = '#ff0000';
  ctx.fillRect(10, 10, 100 * (player.health / 5), 20);
  ctx.strokeStyle = '#000';
  ctx.strokeRect(10, 10, 100, 20);
  
  // Draw hunger bar
  ctx.fillStyle = '#00ff00';
  ctx.fillRect(10, 40, 100 * (player.hunger / 10), 20);
  ctx.strokeStyle = '#000';
  ctx.strokeRect(10, 40, 100, 20);
  
  // Draw timer
  ctx.fillStyle = '#000';
  ctx.font = '20px Arial';
  ctx.textAlign = 'right';
  ctx.fillText(`Time: ${Math.floor(survivalTimer / 1000)}s`, CANVAS_WIDTH - 10, 30);
}

function drawStartScreen() {
  ctx.fillStyle = '#000';
  ctx.font = '48px Arial';
  ctx.textAlign = 'center';
  ctx.fillText('Hungry Penguin', CANVAS_WIDTH / 2, CANVAS_HEIGHT / 3);
  
  ctx.font = '24px Arial';
  ctx.fillText('Press SPACE to Start', CANVAS_WIDTH / 2, CANVAS_HEIGHT / 2);
  ctx.fillText('Press H for Help', CANVAS_WIDTH / 2, CANVAS_HEIGHT / 2 + 40);
}

function drawPauseScreen() {
  ctx.fillStyle = 'rgba(0, 0, 0, 0.5)';
  ctx.fillRect(0, 0, CANVAS_WIDTH, CANVAS_HEIGHT);
  
  ctx.fillStyle = '#fff';
  ctx.font = '24px Arial';
  ctx.textAlign = 'center';
  ctx.fillText('PAUSED', CANVAS_WIDTH / 2, CANVAS_HEIGHT / 2);
  ctx.fillText('Press SPACE to Resume', CANVAS_WIDTH / 2, CANVAS_HEIGHT / 2 + 40);
  ctx.fillText('Press R to Restart', CANVAS_WIDTH / 2, CANVAS_HEIGHT / 2 + 80);
}

function drawGameOverScreen() {
  ctx.fillStyle = 'rgba(0, 0, 0, 0.5)';
  ctx.fillRect(0, 0, CANVAS_WIDTH, CANVAS_HEIGHT);
  
  ctx.fillStyle = '#fff';
  ctx.font = '48px Arial';
  ctx.textAlign = 'center';
  ctx.fillText('GAME OVER', CANVAS_WIDTH / 2, CANVAS_HEIGHT / 3);
  
  ctx.font = '24px Arial';
  ctx.fillText(`Survival Time: ${Math.floor(survivalTimer / 1000)}s`, CANVAS_WIDTH / 2, CANVAS_HEIGHT / 2);
  ctx.fillText('Press SPACE to Restart', CANVAS_WIDTH / 2, CANVAS_HEIGHT / 2 + 40);
}

function gameLoop(timestamp) {
  const deltaTime = timestamp - lastTimestamp;
  lastTimestamp = timestamp;
  
  ctx.clearRect(0, 0, CANVAS_WIDTH, CANVAS_HEIGHT);
  
  switch (gameState) {
    case 'start':
      drawStartScreen();
      if (keys.Space) {
        resetGame();
        gameState = 'playing';
      }
      break;
      
    case 'playing':
      survivalTimer += deltaTime;
      updateWorld();
      updatePlayer(deltaTime);
      drawWorld();
      drawPlayer();
      drawUI();
      break;
      
    case 'paused':
      drawWorld();
      drawPlayer();
      drawUI();
      drawPauseScreen();
      break;
      
    case 'gameover':
      drawWorld();
      drawPlayer();
      drawUI();
      drawGameOverScreen();
      break;
  }
  
  requestAnimationFrame(gameLoop);
}

// Start the game loop
requestAnimationFrame(gameLoop);